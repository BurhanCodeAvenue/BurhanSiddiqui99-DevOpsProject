// src/server/utils/authUtils.ts
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { User } from '@/types/user'; // Assuming User type definition

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error('JWT_SECRET environment variable is not defined. Please set it in your .env file.');
}

/**
 * Hashes a password using bcrypt.
 * @param password The plain text password.
 * @returns A promise that resolves to the hashed password.
 */
export const hashPassword = async (password: string): Promise<string> => {
  const saltRounds = 10; // Adjust salt rounds as needed for security/performance balance
  return bcrypt.hash(password, saltRounds);
};

/**
 * Compares a plain text password with a hashed password.
 * @param plainPassword The plain text password to compare.
 * @param hashedPassword The hashed password from the database.
 * @returns A promise that resolves to true if passwords match, false otherwise.
 */
export const comparePassword = async (plainPassword: string, hashedPassword: string): Promise<boolean> => {
  return bcrypt.compare(plainPassword, hashedPassword);
};

/**
 * Generates a JSON Web Token (JWT) for a user.
 * @param user The user object (ensure it contains the user ID).
 * @returns The generated JWT string.
 */
export const generateToken = (user: Pick<User, 'id' | 'email' | 'name'>): string => {
  const payload = {
    id: user.id,
    email: user.email,
    name: user.name,
    // Add other relevant non-sensitive info if needed
  };
  return jwt.sign(payload, JWT_SECRET!, { expiresIn: '1d' }); // Token expires in 1 day
};

/**
 * Verifies a JWT token.
 * @param token The JWT string to verify.
 * @returns The decoded payload if the token is valid, otherwise throws an error.
 */
export const verifyToken = (token: string): jwt.JwtPayload | string => {
  try {
    return jwt.verify(token, JWT_SECRET!);
  } catch (error) {
    console.error('JWT verification failed:', error);
    throw new Error('Invalid or expired token.');
  }
};
