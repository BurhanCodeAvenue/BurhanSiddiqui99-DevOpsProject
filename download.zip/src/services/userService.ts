import api from './api';
import type { User } from '@/types/user';

/**
 * Search for users by name.
 * Requires authentication (token is added by the API interceptor).
 */
export const searchUsersApi = async (nameQuery: string): Promise<User[]> => {
  if (!nameQuery.trim()) {
    return []; // Return empty array if query is empty
  }
  try {
    const response = await api.get<User[]>(`/api/users/search`, {
      params: { name: nameQuery }, // Send query as URL parameter
    });
    return response.data;
  } catch (error: any) {
     console.error("Failed to search users:", error);
     // Rethrow or return a specific error structure
     throw new Error(error.response?.data?.message || "User search failed.");
  }
};

// Add other user-related API calls here (e.g., get user profile)
