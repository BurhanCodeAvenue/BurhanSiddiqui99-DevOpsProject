import axios from 'axios';
import { store } from '@/lib/store'; // Import Redux store

// Define your API base URL (For Next.js API Routes, it's usually just the root)
// If your Next.js app runs on localhost:9002, API routes are at localhost:9002/api/*
// The base URL for axios can be empty or '/' if calling from the same origin.
// Or specify the full origin if needed.
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || ''; // Use environment variable or default to relative path

const api = axios.create({
  baseURL: API_BASE_URL, // Base URL will prepend '/api/...' routes
  headers: {
    'Content-Type': 'application/json',
  },
  // Add withCredentials if using cookies for session management (might be needed for httpOnly cookies later)
  // withCredentials: true,
});

// Add a request interceptor to include the JWT token
api.interceptors.request.use(
  (config) => {
    const token = store.getState().auth.token; // Get token from Redux state
    if (token && config.url?.startsWith('/api/')) { // Only add token to our API routes
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Optional: Add a response interceptor for global error handling or token refresh logic
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle specific errors like 401 Unauthorized (e.g., token expired)
    if (error.response && error.response.status === 401 && error.config.url?.startsWith('/api/')) {
      // Optionally dispatch logout action or redirect to login
      console.error("Unauthorized request - Token might be invalid or expired.");
      // Example: store.dispatch(logoutUser()); // Make sure logoutUser is imported if used
      // Consider redirecting: window.location.href = '/signin';
    }
    // Forward the error so individual calls can handle it
    return Promise.reject(error);
  }
);


export default api;
