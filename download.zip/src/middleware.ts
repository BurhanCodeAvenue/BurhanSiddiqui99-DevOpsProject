// src/middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { verifyToken } from '@/server/utils/authUtils'; // Assuming verifyToken exists

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  console.warn('JWT_SECRET environment variable is not defined. API route protection might not work correctly.');
}

export const config = {
  matcher: [
    /*
     * Match all API routes except for the ones starting with:
     * - api/auth/...(authentication routes)
     * - api/public/... (any explicitly public routes)
     * - api/socket (socket handler) - authentication handled within socket logic
     */
    '/api/((?!auth|public|socket).*)',
     // Optionally protect non-API routes as well
     // '/chat/:path*', // Example: Protect chat pages
  ],
};

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // --- API Route Protection ---
  if (pathname.startsWith('/api/')) {
    if (!JWT_SECRET) {
       console.error('JWT_SECRET is not configured. Cannot verify API token.');
       return NextResponse.json({ message: 'Server configuration error' }, { status: 500 });
    }

    const authHeader = request.headers.get('authorization');
    const token = authHeader?.split(' ')[1]; // Bearer <token>

    if (!token) {
      return NextResponse.json({ message: 'Authentication required' }, { status: 401 });
    }

    try {
      const decoded = verifyToken(token);
      // Token is valid, attach decoded user info to the request headers
      // so downstream API routes can access it if needed (optional)
      const requestHeaders = new Headers(request.headers);
      requestHeaders.set('x-user-id', (decoded as any).id);
      requestHeaders.set('x-user-email', (decoded as any).email);

      // Continue to the API route
      return NextResponse.next({
        request: {
          headers: requestHeaders,
        },
      });

    } catch (error) {
      console.error('API Auth Middleware Error:', error);
      return NextResponse.json({ message: 'Invalid or expired token' }, { status: 401 });
    }
  }

  // --- Page Route Protection (Example) ---
  // if (pathname.startsWith('/chat')) {
  //   const tokenCookie = request.cookies.get('authToken'); // Example: using a cookie
  //   if (!tokenCookie?.value) {
  //     const url = request.nextUrl.clone();
  //     url.pathname = '/signin';
  //     return NextResponse.redirect(url);
  //   }
  //   // Add token verification for page routes if necessary
  //   try {
  //      verifyToken(tokenCookie.value);
  //      // Token is valid, allow access
  //      return NextResponse.next();
  //   } catch (error) {
  //      console.error('Page Auth Middleware Error:', error);
  //      const url = request.nextUrl.clone();
  //      url.pathname = '/signin';
  //      request.cookies.delete('authToken'); // Clear invalid cookie
  //      const response = NextResponse.redirect(url);
  //      response.cookies.delete('authToken'); // Ensure cookie is cleared in response
  //      return response;
  //   }
  // }

  // Allow request to proceed if no protection rules match
  return NextResponse.next();
}
