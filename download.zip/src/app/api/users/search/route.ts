// src/app/api/users/search/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/server/config/firebaseAdmin'; // db might be null
import type { User } from '@/types/user';
import type { NextRequest } from 'next/server';

// This route is protected by the middleware, which verifies the JWT token.
// The middleware adds 'x-user-id' to the headers if the token is valid.

export async function GET(request: NextRequest) {
  // Check if Firebase Admin SDK initialized properly
  if (!db) {
    console.error("User Search Error: Firestore database is not available. Firebase Admin SDK might not have initialized correctly.");
    return NextResponse.json({ message: 'Server configuration error: Database unavailable' }, { status: 500 });
  }

  // Retrieve the user ID added by the middleware (optional, but good practice)
  const userId = request.headers.get('x-user-id');
  if (!userId) {
    // This case should ideally be handled by the middleware, but it's a safety check
    return NextResponse.json({ message: 'Unauthorized: Missing user identification' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const nameQuery = searchParams.get('name');

  if (!nameQuery || nameQuery.trim().length === 0) {
    return NextResponse.json({ message: 'Search query "name" is required' }, { status: 400 });
  }

  try {
    const usersRef = db.collection('users');
    const queryLower = nameQuery.toLowerCase();
    // Firestore doesn't support case-insensitive search natively or partial string matching like SQL's LIKE.
    // A common workaround is to store a lowercase version of the name or use prefix matching.
    // Using prefix matching (starts with):
    // Note: This requires the query to match the beginning of the name.
    const querySnapshot = await usersRef
      .where('name', '>=', nameQuery) // Find names starting with the query (case-sensitive)
      .where('name', '<=', nameQuery + '\uf8ff') // Limit to names starting with the query
      .limit(10) // Limit results for performance
      .get();

    /*
    // Alternative: Store lowercase name field and query that (requires modifying signup)
    const querySnapshot = await usersRef
        .where('name_lowercase', '>=', queryLower)
        .where('name_lowercase', '<=', queryLower + '\uf8ff')
        .limit(10)
        .get();
    */

    const users: User[] = [];
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      // Exclude the current user from the results
      if (doc.id !== userId) {
          users.push({
            id: doc.id,
            name: data.name,
            email: data.email,
            profilePic: data.profilePic,
            // Ensure password is not returned
          });
      }
    });

    // A simple secondary filter for case-insensitivity (if not using lowercase field)
    // This filters the limited results further.
    const filteredUsers = users.filter(user =>
        user.name.toLowerCase().includes(queryLower)
    );


    return NextResponse.json(filteredUsers, { status: 200 });

  } catch (error: any) {
    console.error('User Search Error:', error);
    return NextResponse.json({ message: 'Internal Server Error', error: error.message || 'Unknown error' }, { status: 500 });
  }
}
