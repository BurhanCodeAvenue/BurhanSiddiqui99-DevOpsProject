"use client";

import React, { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@/lib/store';
import { setOnlineUsers, addMessage } from '@/lib/features/chat/chatSlice'; // Import addMessage if needed elsewhere
import type { Message } from '@/types/message';
import { useToast } from "@/hooks/use-toast";


interface SocketContextProps {
  socket: Socket | null;
  isConnected: boolean;
}

const SocketContext = createContext<SocketContextProps>({
  socket: null,
  isConnected: false,
});

export const useSocket = () => {
  return useContext(SocketContext);
};

interface SocketProviderProps {
  children: ReactNode;
  userId: string; // Pass the logged-in user ID
  token: string; // Pass the auth token
}

// Define your Socket.IO server URL (replace with your actual backend URL)
const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5001'; // Use environment variable or default

export const SocketProvider = ({ children, userId, token }: SocketProviderProps) => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
   const { toast } = useToast();

  const connectSocket = useCallback(() => {
     // Prevent multiple connections
    if (socket?.connected) {
        console.log("Socket already connected.");
        return;
    }

    console.log('Attempting to connect socket...');
    const newSocket = io(SOCKET_URL, {
      query: { userId }, // Pass user ID for server-side mapping
      auth: { token }, // Pass JWT token for authentication
      reconnection: true, // Enable auto-reconnection
      reconnectionAttempts: 5, // Number of attempts
      reconnectionDelay: 1000, // Delay between attempts
    });

    newSocket.on('connect', () => {
      console.log('Socket connected:', newSocket.id);
      setIsConnected(true);
      // Optional: Notify user of connection
       toast({ title: "Connected", description: "Real-time chat enabled." });
       // Server should emit 'update-online-users' after successful connection/authentication
    });

    newSocket.on('disconnect', (reason) => {
      console.log('Socket disconnected:', reason);
      setIsConnected(false);
      // Optional: Notify user of disconnection
       toast({ variant:"destructive", title: "Disconnected", description: `Chat disconnected: ${reason}. Attempting to reconnect...` });
        // Clear online users on disconnect? Or handle server-side persistence?
       dispatch(setOnlineUsers([]));
    });

    newSocket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      setIsConnected(false);
      // Optional: Notify user of connection error
       toast({ variant:"destructive", title: "Connection Error", description: "Could not connect to chat server." });
        // Optionally attempt manual reconnect after a delay, or rely on auto-reconnect
    });

    // Listen for online users update from server
    newSocket.on('update-online-users', (onlineUserIds: string[]) => {
       console.log("Received online users:", onlineUserIds);
       dispatch(setOnlineUsers(onlineUserIds));
    });

     // Listen for receive-message (moved handling primarily to ChatWindow)
     // You might keep a listener here for notifications or global updates
     // newSocket.on('receive-message', (message: Message) => {
     //   console.log("Global socket listener received message:", message);
     //   // Potentially show a global notification if chat window isn't active
     // });

    setSocket(newSocket);

  }, [userId, token, dispatch, toast, socket]); // Add socket to dependency array

   useEffect(() => {
    if (userId && token) {
      connectSocket();
    }

    // Cleanup on component unmount or when userId/token changes
    return () => {
      if (socket) {
        console.log('Disconnecting socket...');
        socket.disconnect();
        setSocket(null);
        setIsConnected(false);
      }
    };
  }, [userId, token, connectSocket]); // Rerun effect if userId or token changes

  return (
    <SocketContext.Provider value={{ socket, isConnected }}>
      {children}
    </SocketContext.Provider>
  );
};
