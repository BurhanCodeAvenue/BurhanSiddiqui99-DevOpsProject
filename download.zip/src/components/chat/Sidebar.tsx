"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "@/lib/store";
import { setActiveChatUser } from "@/lib/features/chat/chatSlice";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LogOut, Search, Loader2, User as UserIcon } from "lucide-react";
import type { User } from "@/types/user";
import { searchUsersApi } from "@/services/userService"; // Assuming userService exists
import { useToast } from "@/hooks/use-toast";
import { useSocket } from "@/context/SocketContext"; // Import useSocket hook

interface SidebarProps {
  user: User;
  onLogout: () => void;
}

export default function Sidebar({ user, onLogout }: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const { activeChatUser } = useSelector((state: RootState) => state.chat);
  const { onlineUsers } = useSelector((state: RootState) => state.chat); // Get online users from Redux
  const { toast } = useToast();
   const { socket } = useSocket(); // Get socket instance

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    try {
      const results = await searchUsersApi(searchQuery);
      // Filter out the current user from search results
      setSearchResults(results.filter(u => u.id !== user.id));
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Search Failed",
        description: error.message || "Could not fetch users.",
      });
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, toast, user.id]);

  // Debounce search
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      handleSearch();
    }, 300); // Debounce search by 300ms

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery, handleSearch]);

  const handleSelectUser = (selectedUser: User) => {
    dispatch(setActiveChatUser(selectedUser));
    setSearchQuery(""); // Clear search after selection
    setSearchResults([]);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <aside className="w-full md:w-80 lg:w-96 flex flex-col border-r bg-card h-full">
      {/* User Profile Section */}
      <div className="p-4 border-b flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user.profilePic} alt={user.name} />
            <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
              {getInitials(user.name)}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="font-semibold text-card-foreground">{user.name}</span>
            <span className="text-xs text-muted-foreground">{user.email}</span>
           </div>
        </div>
        <Button variant="ghost" size="icon" onClick={onLogout} aria-label="Logout">
          <LogOut className="h-5 w-5 text-muted-foreground hover:text-destructive" />
        </Button>
      </div>

      {/* Search Bar */}
      <div className="p-4 border-b">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 w-full"
            aria-label="Search users"
          />
          {isSearching && <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />}
        </div>
      </div>

      {/* User List / Search Results */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {searchResults.length > 0 ? (
            searchResults.map((resultUser) => (
              <Button
                key={resultUser.id}
                variant={activeChatUser?.id === resultUser.id ? "secondary" : "ghost"}
                className="w-full justify-start h-auto py-2 px-3"
                onClick={() => handleSelectUser(resultUser)}
              >
                <Avatar className="h-9 w-9 mr-3">
                  <AvatarImage src={resultUser.profilePic} alt={resultUser.name} />
                  <AvatarFallback className="bg-muted text-muted-foreground">
                    {getInitials(resultUser.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 text-left truncate">
                  <p className="font-medium text-sm text-card-foreground truncate">{resultUser.name}</p>
                   {/* Show online status */}
                  <span className={`text-xs ${onlineUsers.includes(resultUser.id) ? 'text-green-500' : 'text-muted-foreground'}`}>
                    {onlineUsers.includes(resultUser.id) ? 'Online' : 'Offline'}
                  </span>
                </div>
              </Button>
            ))
          ) : searchQuery && !isSearching ? (
             <p className="text-center text-sm text-muted-foreground py-4">No users found.</p>
          ) : !searchQuery && !isSearching ? (
            <p className="text-center text-sm text-muted-foreground py-4">Search for users to start a chat.</p>
          ) : null}

          {/* Placeholder for recent chats - could be implemented later */}
          {/* {!searchQuery && (
             <div className="text-center text-sm text-muted-foreground py-4">
               No recent chats. Search above.
             </div>
          )} */}
        </div>
      </ScrollArea>
    </aside>
  );
}
